'use strict';
(function () {

    console.log("Hi!");
    function Product(name, price, expirationDate) {
        this.id = (function () {
            var productId;
            for (var i = 0; i < 5;) {
                productId = Math.floor((Math.random() * 9000) + 10000);
                i++;
            }
            return productId;
        })();
        this.name = name;
        this.price = price;
        this.expirationDate = expirationDate;
        this.getInfo = function () {
            return this.name + " -> " + this.id + ", " + this.name + ", " + this.price;
        }
    }
    var coffeeExpirationDate = new Date(2018, 7, 13);
    var chocolateExpirationDate = new Date(2019, 2, 5)
    var coffee = new Product("Grand kafa", 102.45, coffeeExpirationDate);
    var chocolate = new Product("Najlepse zelje", 120.345, chocolateExpirationDate);

    console.log(coffee.getInfo());

    function ShoppingBag() {
        this.listOfProducts = [];
        this.getAverage = function () {
            var totalPrice = 0;

            for (var i = 0; i < this.listOfProducts.length; i++) {
                totalPrice += this.listOfProducts[i].price
            }

            return totalPrice / this.listOfProducts.length;
        }

        this.getMostExpensive = function() {
            var max;
            for (i = 0; i<listOfProducts.length; i++) {
                max = listOfProducts[0];
                if (listOfProducts[i]>max ) {
                    max = listOfProducts[i]
                }
            }
            return max;
        }

        console.log(max.getMostExpensive());
        
        this.getTotalPrice = function () {
            var sum = 0;
            for (i = 0; i<listOfProducts.length; i++) {
                sum += listOfProducts[i];
            }
            return sum;
        }

//         function ShopingList() {
//         this.list = [];
// this.addProduct = function (p) {
//     //proveravamo da li je validan datum 
//     this.list.push(p);
// }
// var jsList = new shoppingBag()
// jsList.addProduct(coffee, chocolate)
//  console.log(jsList.list);
//         }*/
    }
    function PaymentCard() {
        this.accountBalance = accountBalance;
        this.status = (function ()

    ) 
    }

})();
